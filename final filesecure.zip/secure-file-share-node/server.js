const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const mime = require('mime-types');

require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const UPLOAD_DIR = path.join(__dirname, 'uploads');

if (!fs.existsSync(UPLOAD_DIR)) {
    fs.mkdirSync(UPLOAD_DIR);
}

app.use(express.json()); // for parsing JSON bodies
app.use(express.static('public'));

// AES Config
const ALGORITHM = 'aes-256-gcm';
const SECRET_KEY = Buffer.from(process.env.AES_SECRET_KEY || '', 'utf-8');

// Check AES key length early
if (!SECRET_KEY || SECRET_KEY.length !== 32) {
    console.error('Error: AES_SECRET_KEY must be defined in .env file and be 32 bytes long.');
    process.exit(1);
}

const IV_LENGTH = 16;

// JWT Config
const JWT_SECRET = process.env.JWT_SECRET || "supersecretjwtkey";

// User store (in-memory for now)
let users = {};

// Multer storage
const storage = multer.memoryStorage();
const upload = multer({ storage });

// ---------------- AUTH HELPERS ----------------
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ error: "Access denied, token missing" });

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ error: "Invalid token" });
        req.user = user;
        next();
    });
}

// ---------------- ENCRYPTION ----------------
function encrypt(buffer) {
    const iv = crypto.randomBytes(IV_LENGTH);
    const cipher = crypto.createCipheriv(ALGORITHM, SECRET_KEY, iv);
    const encrypted = Buffer.concat([cipher.update(buffer), cipher.final()]);
    const authTag = cipher.getAuthTag();
    return Buffer.concat([iv, authTag, encrypted]);
}

function decrypt(buffer) {
    const iv = buffer.slice(0, IV_LENGTH);
    const authTag = buffer.slice(IV_LENGTH, IV_LENGTH + 16);
    const encrypted = buffer.slice(IV_LENGTH + 16);
    const decipher = crypto.createDecipheriv(ALGORITHM, SECRET_KEY, iv);
    decipher.setAuthTag(authTag);
    return Buffer.concat([decipher.update(encrypted), decipher.final()]);
}

// ---------------- AUTH ROUTES ----------------
app.post('/register', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ error: "Username and password required" });
    if (users[username]) return res.status(400).json({ error: "User already exists" });

    const hashedPassword = await bcrypt.hash(password, 10);
    users[username] = { password: hashedPassword };
    res.json({ message: "User registered successfully" });
});

app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = users[username];
    if (!user) return res.status(400).json({ error: "Invalid username or password" });

    const validPass = await bcrypt.compare(password, user.password);
    if (!validPass) return res.status(400).json({ error: "Invalid username or password" });

    const token = jwt.sign({ username }, JWT_SECRET, { expiresIn: "1h" });
    res.json({ message: "Login successful", token });
});

// ---------------- FILE ROUTES ----------------
app.post('/upload', authenticateToken, upload.single("file"), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: "No file uploaded!" });
    }

    const fileBuffer = req.file.buffer;
    const encryptedBuffer = encrypt(fileBuffer);
    const filePath = path.join(UPLOAD_DIR, req.file.originalname + '.enc');

    fs.writeFileSync(filePath, encryptedBuffer);

    res.json({
        message: "File uploaded and encrypted successfully",
        file: req.file.originalname
    });
});

app.get('/download/:filename', authenticateToken, (req, res) => {
    try {
        const filename = req.params.filename;

        if (filename.includes('/') || filename.includes('\\')) {
            return res.status(400).json({ error: 'Invalid filename' });
        }

        const filePath = path.join(UPLOAD_DIR, filename + '.enc');

        console.log('Requested download for:', filename);
        console.log('Checking file at:', filePath);
        console.log('File exists:', fs.existsSync(filePath));

        if (!fs.existsSync(filePath)) {
            return res.status(404).json({ error: 'File not found' });
        }

        const encryptedBuffer = fs.readFileSync(filePath);
        const decryptedBuffer = decrypt(encryptedBuffer);

        const contentType = mime.lookup(filename) || 'application/octet-stream';
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.setHeader('Content-Type', contentType);

        res.status(200).send(decryptedBuffer);

    } catch (error) {
        console.error('Decryption or download error:', error);
        res.status(500).json({ error: 'Failed to decrypt or send file' });
    }
});

// ---------------- START SERVER ----------------
app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});
