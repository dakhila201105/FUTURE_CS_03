# Secure File Share (Node.js + AES Encryption)

## 🚀 Features
- Upload files securely with AES-256-GCM encryption
- Download and decrypt files
- Simple web UI for interaction
- Environment-based key management

## ⚡ Setup & Run
1. Install dependencies
   ```bash
   npm install
   ```

2. Copy `.env.example` to `.env` and add a **32-byte AES key** (use `node -e "console.log(require('crypto').randomBytes(32).toString('utf-8'))"` to generate one).

3. Run the server
   ```bash
   npm start
   ```

4. Open browser at [http://localhost:3000](http://localhost:3000)

## 📂 Project Structure
- `server.js` → Express backend with AES encryption
- `public/` → Frontend (HTML)
- `uploads/` → Encrypted files storage
- `.env` → Environment variables

---
🔐 Built for internship project on **Secure File Sharing**.
